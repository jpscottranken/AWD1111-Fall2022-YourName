# Ice Cream Store Web Service

A simple web which server REST APIs. Ice Cream Store Web Service provides APIs to create/view menus and ordering.

This repository is made for NodeJS tutorial 2022.
